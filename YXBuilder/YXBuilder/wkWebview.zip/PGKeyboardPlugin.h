//
//  PGKeyboardPlugin.h
//  YXBuilder
//
//  Created by LiYuan on 2017/11/9.
//  Copyright © 2017年 YUSYS. All rights reserved.
//

#import "PGPlugin.h"

@interface PGKeyboardPlugin : PGPlugin

@end
