//
//  PGPlugin.m
//  YXBuilder
//
//  Created by LiYuan on 2017/11/9.
//  Copyright © 2017年 YUSYS. All rights reserved.
//

#import "PGPlugin.h"

@implementation PGPlugin

WKWebView *_webView_;

+ (void)setWebView:(WKWebView *)webView {
    _webView_ = webView;
}

- (instancetype)init {
    if (!self) {
        self = [super init];
    }
    [WKWebViewJavascriptBridge enableLogging];
    _webViewBridge = [WKWebViewJavascriptBridge bridgeForWebView:_webView_];
    [_webViewBridge setWebViewDelegate:self];
    _webView = _webView_;
        
    return self;
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSString *urlstring = [navigationAction.request.URL.absoluteString stringByRemovingPercentEncoding];// 解码
    NSLog(@"url = >%@",urlstring);
#warning todo 4、截获请求URL
    if (urlstring) {
        decisionHandler(WKNavigationActionPolicyAllow);
    } else {
        decisionHandler(WKNavigationActionPolicyCancel);
    }
    
}

@end
